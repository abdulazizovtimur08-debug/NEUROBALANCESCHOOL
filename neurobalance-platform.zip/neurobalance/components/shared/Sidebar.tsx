'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard, ClipboardList, HeartHandshake, CalendarDays,
  Stethoscope, FileText, Star, BarChart3, Bot, User, Bell,
  Brain, LogOut, ChevronRight,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useI18n } from '@/lib/i18n';
import { getNavItemsForRole } from '@/lib/rbac';
import type { UserRole, AppLanguage } from '@/types';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard, ClipboardList, HeartHandshake, CalendarDays,
  Stethoscope, FileText, Star, BarChart3, Bot, User,
};

const LANG_OPTIONS: { code: AppLanguage; label: string }[] = [
  { code: 'uz', label: 'UZ' },
  { code: 'ru', label: 'RU' },
  { code: 'en', label: 'EN' },
];

const ROLE_COLORS: Record<UserRole, string> = {
  student:      'bg-calm-100 text-calm-700',
  staff:        'bg-sage-100 text-sage-700',
  psychologist: 'bg-warm-100 text-warm-700',
  director:     'bg-purple-100 text-purple-700',
  admin:        'bg-orange-100 text-orange-700',
};

interface SidebarProps {
  collapsed?: boolean;
}

export function Sidebar({ collapsed = false }: SidebarProps) {
  const pathname = usePathname();
  const { profile, signOut } = useAuth();
  const { t, language, setLanguage } = useI18n();

  if (!profile) return null;

  const navItems = getNavItemsForRole(profile.role);

  return (
    <aside
      className={`
        flex flex-col h-full bg-card border-r border-border/60
        ${collapsed ? 'w-16' : 'w-64'}
        transition-all duration-200
      `}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-border/60">
        <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
          <Brain className="w-4 h-4 text-primary-foreground" />
        </div>
        {!collapsed && (
          <span className="font-display text-lg text-foreground">NeuroBalance</span>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = ICON_MAP[item.icon] ?? LayoutDashboard;
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');

          return (
            <Link
              key={item.key}
              href={item.href}
              className={`nb-sidebar-item ${isActive ? 'nb-sidebar-item-active' : ''} ${
                collapsed ? 'justify-center px-2' : ''
              }`}
              title={collapsed ? t(`nav.${item.key}`) : undefined}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {!collapsed && (
                <>
                  <span className="flex-1">{t(`nav.${item.key}`)}</span>
                  {isActive && <ChevronRight className="w-3 h-3 opacity-50" />}
                </>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Language switcher */}
      {!collapsed && (
        <div className="px-4 py-3 border-t border-border/60">
          <div className="flex gap-1">
            {LANG_OPTIONS.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`flex-1 py-1 rounded-lg text-xs font-medium transition-colors ${
                  language === lang.code
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-secondary'
                }`}
              >
                {lang.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* User profile */}
      <div className={`p-3 border-t border-border/60 ${collapsed ? 'flex justify-center' : ''}`}>
        {collapsed ? (
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
            {profile.displayName.charAt(0)}
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary flex-shrink-0">
              {profile.displayName.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-foreground truncate">
                {profile.displayName}
              </div>
              <span className={`text-xs px-1.5 py-0.5 rounded-md font-medium ${ROLE_COLORS[profile.role]}`}>
                {t(`auth.roles.${profile.role}`)}
              </span>
            </div>
            <button
              onClick={signOut}
              className="text-muted-foreground hover:text-foreground transition-colors"
              title={t('auth.signOut')}
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
}
