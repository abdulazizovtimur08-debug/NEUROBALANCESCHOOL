'use client';

import { useState } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import { Lock, CheckCircle2, ChevronDown } from 'lucide-react';
import type { RiskLevel } from '@/types';

const RISK_LEVELS: RiskLevel[] = ['none', 'low', 'moderate', 'high', 'critical'];

const RISK_COLORS: Record<RiskLevel, string> = {
  none: 'border-calm-300 bg-calm-50 text-calm-700',
  low: 'border-calm-200 bg-calm-50/50 text-calm-600',
  moderate: 'border-warm-300 bg-warm-50 text-warm-700',
  high: 'border-orange-300 bg-orange-50 text-orange-700',
  critical: 'border-red-400 bg-red-50 text-red-700',
};

export default function SessionNotesPage() {
  const { t } = useI18n();

  const [summary, setSummary] = useState('');
  const [recommendations, setRecommendations] = useState('');
  const [followUpNeeded, setFollowUpNeeded] = useState(false);
  const [followUpDate, setFollowUpDate] = useState('');
  const [riskLevel, setRiskLevel] = useState<RiskLevel>('none');
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    // TODO: Save to Firestore via services/notes.ts
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto space-y-6 fade-in">
        {/* Header */}
        <div>
          <h1 className="nb-page-title mb-1">{t('sessionNotes.title')}</h1>
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Lock className="w-4 h-4 text-primary" />
            {t('sessionNotes.private')}
          </div>
        </div>

        {/* Note form */}
        <div className="space-y-4">
          {/* Summary */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('sessionNotes.summary')} *</label>
            <textarea
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder={t('sessionNotes.summaryPlaceholder')}
              className="nb-textarea h-28"
            />
          </div>

          {/* Recommendations */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('sessionNotes.recommendations')}</label>
            <textarea
              value={recommendations}
              onChange={(e) => setRecommendations(e.target.value)}
              placeholder={t('sessionNotes.recommendationsPlaceholder')}
              className="nb-textarea h-24"
            />
          </div>

          {/* Risk level */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('sessionNotes.riskLevel')}</label>
            <div className="grid grid-cols-5 gap-2">
              {RISK_LEVELS.map((level) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setRiskLevel(level)}
                  className={`
                    px-2 py-2 rounded-xl border-2 text-xs font-medium transition-all
                    ${riskLevel === level ? RISK_COLORS[level] + ' border-current shadow-sm scale-105' : 'border-border text-muted-foreground hover:border-border/80'}
                  `}
                >
                  {t(`screening.riskLevels.${level}`).split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Follow-up */}
          <div className="nb-card p-5 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">{t('sessionNotes.followUpNeeded')}</label>
              <button
                type="button"
                onClick={() => setFollowUpNeeded(!followUpNeeded)}
                className={`w-11 h-6 rounded-full transition-colors duration-200 ${
                  followUpNeeded ? 'bg-primary' : 'bg-border'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 mx-0.5 ${
                    followUpNeeded ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {followUpNeeded && (
              <div className="space-y-2">
                <label className="nb-label">{t('sessionNotes.followUpDate')}</label>
                <input
                  type="date"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="nb-input"
                />
              </div>
            )}
          </div>

          {/* Save button */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleSave}
              disabled={loading || !summary}
              className="nb-btn-primary flex-1"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Saqlanmoqda...
                </span>
              ) : (
                t('common.save')
              )}
            </button>

            {saved && (
              <div className="flex items-center gap-1.5 text-calm-600 text-sm fade-in">
                <CheckCircle2 className="w-4 h-4" />
                {t('sessionNotes.saved')}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
