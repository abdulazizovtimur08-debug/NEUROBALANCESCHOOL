import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from '@/lib/auth-context';
import { I18nProvider } from '@/lib/i18n';

export const metadata: Metadata = {
  title: 'NeuroBalance – School Mental Health Platform',
  description:
    'A secure, multilingual platform for school psychological screening, counseling, and wellbeing monitoring.',
  keywords: ['school counseling', 'mental health', 'psychological screening'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body>
        <AuthProvider>
          <I18nProvider defaultLanguage="uz">
            {children}
          </I18nProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
