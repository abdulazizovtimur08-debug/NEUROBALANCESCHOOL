'use client';

import { useAuth } from '@/lib/auth-context';
import { useI18n } from '@/lib/i18n';
import { AppShell } from '@/components/shared/AppShell';
import {
  ClipboardList, HeartHandshake, CalendarDays, Bot,
  TrendingUp, Clock, ChevronRight, Sparkles,
} from 'lucide-react';
import Link from 'next/link';

function getGreeting(t: (key: string) => string): string {
  const hour = new Date().getHours();
  if (hour < 12) return t('dashboard.greeting.morning');
  if (hour < 17) return t('dashboard.greeting.afternoon');
  return t('dashboard.greeting.evening');
}

function ScoreRing({ score, size = 80 }: { score: number; size?: number }) {
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  const color = score >= 75 ? '#3d8872' : score >= 50 ? '#d98c3c' : '#ef4444';

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="currentColor" strokeWidth={5} className="text-border" />
        <circle
          cx={size / 2} cy={size / 2} r={radius} fill="none"
          stroke={color} strokeWidth={5}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.8s ease' }}
        />
      </svg>
      <span className="absolute text-sm font-semibold" style={{ color }}>{score}</span>
    </div>
  );
}

export default function DashboardPage() {
  const { profile } = useAuth();
  const { t } = useI18n();

  if (!profile) return null;

  const greeting = getGreeting(t);

  // Mock data – in production, these come from Firestore via hooks
  const mockScore = 72;
  const mockNextSession = {
    date: 'Ertaga, 10:00',
    psychologist: 'Nilufar Karimova',
    format: 'online',
  };

  const quickActions = [
    {
      href: '/screening',
      icon: ClipboardList,
      label: t('dashboard.startScreening'),
      color: 'bg-calm-50 text-calm-700 border-calm-200',
    },
    {
      href: '/help-request',
      icon: HeartHandshake,
      label: t('dashboard.requestHelp'),
      color: 'bg-warm-50 text-warm-700 border-warm-200',
    },
    {
      href: '/schedule',
      icon: CalendarDays,
      label: t('dashboard.viewSchedule'),
      color: 'bg-sage-50 text-sage-700 border-sage-200',
    },
    {
      href: '/ai-advisor',
      icon: Bot,
      label: t('nav.aiAdvisor'),
      color: 'bg-purple-50 text-purple-700 border-purple-200',
    },
  ];

  const showStudentDash = profile.role === 'student' || profile.role === 'staff';

  return (
    <AppShell>
      <div className="space-y-8 fade-in">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <p className="text-muted-foreground text-sm mb-1">{greeting},</p>
            <h1 className="nb-page-title">{profile.displayName}</h1>
          </div>
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-calm-50 border border-calm-200 text-calm-700 text-xs font-medium">
            <Sparkles className="w-3 h-3" />
            {t(`auth.roles.${profile.role}`)}
          </div>
        </div>

        {/* Student/Staff view */}
        {showStudentDash && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Wellbeing score */}
            <div className="nb-card p-6 flex items-center gap-6 stagger-1 fade-in">
              <ScoreRing score={mockScore} size={88} />
              <div>
                <p className="nb-label mb-1">{t('dashboard.wellbeingScore')}</p>
                <p className="text-2xl font-semibold text-foreground">{mockScore}/100</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  <TrendingUp className="w-3 h-3 inline mr-1 text-calm-500" />
                  +4 dan oldingi skreening
                </p>
              </div>
            </div>

            {/* Next session */}
            <div className="nb-card p-6 stagger-2 fade-in">
              <p className="nb-label mb-3">{t('dashboard.nextSession')}</p>
              {mockNextSession ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">{mockNextSession.date}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{mockNextSession.psychologist}</p>
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-calm-100 text-calm-700 border border-calm-200">
                    {t(`schedule.format.${mockNextSession.format}`)}
                  </span>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">{t('dashboard.noUpcomingSessions')}</p>
              )}
            </div>

            {/* Screening history */}
            <div className="nb-card p-6 stagger-3 fade-in">
              <p className="nb-label mb-3">{t('dashboard.recentScreening')}</p>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Kayfiyat</span>
                  <span className="font-medium text-calm-600">76</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Stress</span>
                  <span className="font-medium text-warm-600">58</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Uyqu</span>
                  <span className="font-medium text-calm-600">82</span>
                </div>
                <Link
                  href="/screening"
                  className="flex items-center gap-1 text-xs text-primary hover:text-primary/80 mt-2 transition-colors"
                >
                  Batafsil <ChevronRight className="w-3 h-3" />
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Quick actions */}
        <div className="stagger-4 fade-in">
          <h2 className="nb-section-title mb-4">{t('dashboard.quickActions')}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Link
                  key={action.href}
                  href={action.href}
                  className={`nb-card p-4 flex flex-col items-center gap-3 text-center border hover:shadow-md transition-all duration-150 active:scale-[0.98] ${action.color}`}
                >
                  <div className="w-10 h-10 rounded-xl bg-white/60 flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-medium leading-tight">{action.label}</span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Psychologist: show pending requests summary */}
        {profile.role === 'psychologist' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 stagger-2 fade-in">
            {[
              { label: 'Yangi so\'rovlar', value: 3, color: 'text-warm-600', bg: 'bg-warm-50 border-warm-200' },
              { label: 'Bugungi seanslar', value: 4, color: 'text-calm-600', bg: 'bg-calm-50 border-calm-200' },
              { label: 'Kuzatuv kerak', value: 2, color: 'text-orange-600', bg: 'bg-orange-50 border-orange-200' },
            ].map((stat) => (
              <div key={stat.label} className={`nb-card p-6 border ${stat.bg}`}>
                <p className="nb-label mb-2">{stat.label}</p>
                <p className={`text-4xl font-display font-semibold ${stat.color}`}>{stat.value}</p>
              </div>
            ))}
          </div>
        )}

        {/* Director: redirect hint */}
        {profile.role === 'director' && (
          <div className="nb-card p-6 stagger-2 fade-in flex items-center justify-between">
            <div>
              <h2 className="nb-section-title mb-1">KPI Boshqaruv paneli</h2>
              <p className="text-sm text-muted-foreground">Maktab ko'rsatkichlari va statistikasi</p>
            </div>
            <Link href="/director" className="nb-btn-primary">
              Ko'rish <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        )}
      </div>
    </AppShell>
  );
}
