'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { useI18n } from '@/lib/i18n';
import { Eye, EyeOff, Brain, Globe, AlertCircle } from 'lucide-react';
import type { AppLanguage } from '@/types';

const LANGUAGE_OPTIONS: { code: AppLanguage; label: string; flag: string }[] = [
  { code: 'uz', label: "O'zbek", flag: '🇺🇿' },
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
];

export default function SignInPage() {
  const { signIn } = useAuth();
  const { t, language, setLanguage } = useI18n();
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await signIn(email, password);
      router.push('/dashboard');
    } catch {
      setError(t('auth.invalidCredentials'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-calm-50 via-background to-sage-50 flex">
      {/* Left decorative panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-calm-600 to-calm-800 relative overflow-hidden flex-col justify-between p-12">
        {/* Background circles */}
        <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-white/5" />
        <div className="absolute -bottom-32 -right-32 w-[500px] h-[500px] rounded-full bg-white/5" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-white/5" />

        {/* Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="text-white font-display text-xl">NeuroBalance</span>
        </div>

        {/* Hero text */}
        <div className="relative z-10 space-y-6">
          <h1 className="text-4xl lg:text-5xl font-display text-white leading-tight">
            Maktabingiz<br />
            <span className="text-calm-200">psixologik sog'ligi</span><br />
            uchun platforma
          </h1>
          <p className="text-calm-100 text-lg leading-relaxed max-w-sm">
            Xavfsiz, maxfiy va ko'p tilli platforma — o'quvchilar, xodimlar va psixologlar uchun.
          </p>

          <div className="flex flex-wrap gap-3">
            {['Skreening', 'Maslahat', 'Monitoring', 'AI Yordam'].map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full bg-white/10 text-white/80 text-sm border border-white/20"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 flex gap-8">
          {[
            { value: '5', label: 'Rollar' },
            { value: '3', label: 'Tillar' },
            { value: '100%', label: 'Maxfiy' },
          ].map((stat) => (
            <div key={stat.label}>
              <div className="text-2xl font-semibold text-white">{stat.value}</div>
              <div className="text-calm-200 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Right: sign-in form */}
      <div className="flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-16 xl:px-24">
        {/* Language switcher */}
        <div className="absolute top-6 right-6 flex items-center gap-2">
          <Globe className="w-4 h-4 text-muted-foreground" />
          <div className="flex gap-1">
            {LANGUAGE_OPTIONS.map((lang) => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`px-2 py-1 rounded-lg text-xs font-medium transition-colors ${
                  language === lang.code
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-secondary'
                }`}
              >
                {lang.flag} {lang.label}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile logo */}
        <div className="lg:hidden flex items-center gap-3 mb-10">
          <div className="w-9 h-9 rounded-2xl bg-primary flex items-center justify-center">
            <Brain className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-display text-xl text-foreground">NeuroBalance</span>
        </div>

        <div className="max-w-sm w-full mx-auto lg:mx-0 fade-in">
          <div className="mb-8">
            <h2 className="text-3xl font-display text-foreground mb-2">
              {t('auth.welcomeBack')}
            </h2>
            <p className="text-muted-foreground">{t('auth.signIn')}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div className="space-y-2">
              <label className="nb-label">{t('auth.email')}</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@school.edu"
                className="nb-input"
                required
                autoComplete="email"
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <label className="nb-label">{t('auth.password')}</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="nb-input pr-10"
                  required
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-destructive/10 text-destructive text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}

            {/* Forgot password */}
            <div className="flex justify-end">
              <button
                type="button"
                className="text-sm text-primary hover:text-primary/80 transition-colors"
              >
                {t('auth.forgotPassword')}
              </button>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="nb-btn-primary w-full"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {t('common.loading')}
                </span>
              ) : (
                t('auth.signInButton')
              )}
            </button>
          </form>

          {/* Demo credentials note */}
          <div className="mt-8 p-4 rounded-xl bg-muted/50 border border-border/50">
            <p className="text-xs text-muted-foreground mb-2 font-medium">Demo kirish ma'lumotlari:</p>
            <div className="space-y-1 text-xs text-muted-foreground font-mono">
              <div>student@demo.school.uz / demo123</div>
              <div>psixolog@demo.school.uz / demo123</div>
              <div>direktor@demo.school.uz / demo123</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
