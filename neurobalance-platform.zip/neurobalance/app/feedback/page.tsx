'use client';

import { useState } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import { Star, CheckCircle2 } from 'lucide-react';

export default function FeedbackPage() {
  const { t } = useI18n();

  const [rating, setRating] = useState<number>(0);
  const [hover, setHover] = useState<number>(0);
  const [comment, setComment] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!rating) return;
    setLoading(true);
    // TODO: Save to Firestore via services/feedback.ts
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <AppShell>
        <div className="max-w-md mx-auto text-center py-16 fade-in space-y-6">
          <div className="w-20 h-20 rounded-full bg-calm-100 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10 text-calm-600" />
          </div>
          <div>
            <h1 className="nb-page-title mb-2">{t('feedback.submitted')}</h1>
          </div>
          <a href="/dashboard" className="nb-btn-primary">
            Bosh sahifaga qaytish
          </a>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="max-w-md mx-auto space-y-6 fade-in">
        <div>
          <h1 className="nb-page-title mb-1">{t('feedback.title')}</h1>
        </div>

        {/* Star rating */}
        <div className="nb-card p-6 text-center space-y-4">
          <label className="nb-label">{t('feedback.rating')}</label>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onMouseEnter={() => setHover(star)}
                onMouseLeave={() => setHover(0)}
                onClick={() => setRating(star)}
                className="transition-all duration-100 active:scale-90"
              >
                <Star
                  className={`w-10 h-10 transition-colors ${
                    star <= (hover || rating)
                      ? 'fill-warm-400 text-warm-400'
                      : 'text-border fill-transparent'
                  }`}
                />
              </button>
            ))}
          </div>
          {(hover || rating) > 0 && (
            <p className="text-sm text-muted-foreground">
              {['', 'Yomon', "O'rtacha", 'Yaxshi', 'Juda yaxshi', 'Ajoyib'][hover || rating]}
            </p>
          )}
        </div>

        {/* Comment */}
        <div className="nb-card p-5 space-y-3">
          <label className="nb-label">{t('feedback.comment')} <span className="normal-case font-normal">({t('common.optional')})</span></label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder={t('feedback.commentPlaceholder')}
            className="nb-textarea h-28"
          />
        </div>

        {/* Anonymous */}
        <div className="nb-card p-4 flex items-center justify-between">
          <span className="text-sm font-medium">{t('feedback.anonymous')}</span>
          <button
            type="button"
            onClick={() => setIsAnonymous(!isAnonymous)}
            className={`w-11 h-6 rounded-full transition-colors duration-200 ${
              isAnonymous ? 'bg-primary' : 'bg-border'
            }`}
          >
            <span
              className={`block w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 mx-0.5 ${
                isAnonymous ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!rating || loading}
          className="nb-btn-primary w-full"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Yuborilmoqda...
            </span>
          ) : (
            t('feedback.submit')
          )}
        </button>
      </div>
    </AppShell>
  );
}
