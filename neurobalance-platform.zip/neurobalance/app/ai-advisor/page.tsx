'use client';

import { useState, useRef, useEffect } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import { Bot, Send, AlertTriangle, HeartHandshake, User, Info } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isEscalation?: boolean;
}

// High-risk phrases that trigger escalation
const HIGH_RISK_KEYWORDS = [
  // uz
  'o\'ldirmoq', 'o\'ziga zarar', 'yashashni xohlamayman', 'o\'lmoqchi',
  // ru
  'убить себя', 'суицид', 'не хочу жить', 'покончить',
  // en
  'kill myself', 'suicide', 'end my life', 'self harm', 'hurt myself',
];

function containsHighRisk(text: string): boolean {
  const lower = text.toLowerCase();
  return HIGH_RISK_KEYWORDS.some((kw) => lower.includes(kw));
}

const QUICK_PROMPTS = [
  "Imtihon oldida qanday tinchlanish mumkin?",
  "Stress bilan qanday kurashaman?",
  "Yaxshi uxlash uchun maslahat bering",
  "Do'stlar bilan munosabatni yaxshilash",
];

export default function AIAdvisorPage() {
  const { t } = useI18n();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      role: 'assistant',
      content: t('aiAdvisor.greeting'),
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isEscalated, setIsEscalated] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (text?: string) => {
    const content = text ?? input.trim();
    if (!content || loading) return;

    setInput('');

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);

    // Check for high-risk content
    if (containsHighRisk(content)) {
      setIsEscalated(true);
      const escalationMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: t('aiAdvisor.escalationMessage'),
        timestamp: new Date(),
        isEscalation: true,
      };
      setMessages((prev) => [...prev, escalationMsg]);
      return;
    }

    setLoading(true);

    // TODO: Call your backend API route which calls Anthropic/OpenAI API
    // For now, simulate a response
    await new Promise((r) => setTimeout(r, 1500));

    const aiResponse = getSimulatedResponse(content);
    const assistantMsg: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: aiResponse,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, assistantMsg]);
    setLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto h-[calc(100vh-8rem)] flex flex-col fade-in">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="font-display text-xl text-foreground">{t('aiAdvisor.title')}</h1>
            <p className="text-xs text-muted-foreground">{t('aiAdvisor.subtitle')}</p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="flex items-start gap-2 p-3 rounded-xl bg-warm-50 border border-warm-200 text-warm-700 text-xs mb-4">
          <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
          {t('aiAdvisor.disclaimer')}
        </div>

        {/* Escalation banner */}
        {isEscalated && (
          <div className="flex items-center justify-between p-4 rounded-xl bg-red-50 border border-red-200 mb-4">
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="w-4 h-4" />
              <span className="text-sm font-medium">Psixolog yordami kerak</span>
            </div>
            <a href="/help-request" className="nb-btn-primary bg-red-600 hover:bg-red-700 text-xs py-1.5 px-3">
              <HeartHandshake className="w-3 h-3" />
              {t('aiAdvisor.requestHelp')}
            </a>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div className={`w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center text-xs ${
                msg.role === 'user'
                  ? 'bg-primary text-primary-foreground'
                  : msg.isEscalation
                  ? 'bg-red-100 text-red-600'
                  : 'bg-secondary text-foreground'
              }`}>
                {msg.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-primary text-primary-foreground rounded-tr-sm'
                    : msg.isEscalation
                    ? 'bg-red-50 text-red-800 border border-red-200 rounded-tl-sm'
                    : 'bg-card border border-border/60 text-foreground rounded-tl-sm'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 text-foreground" />
              </div>
              <div className="bg-card border border-border/60 rounded-2xl rounded-tl-sm px-4 py-3">
                <div className="flex gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce"
                      style={{ animationDelay: `${i * 150}ms` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Quick prompts */}
        {messages.length === 1 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {QUICK_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                onClick={() => sendMessage(prompt)}
                className="text-xs px-3 py-1.5 rounded-full bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground transition-colors border border-border/60"
              >
                {prompt}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="relative mt-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={t('aiAdvisor.inputPlaceholder')}
            className="nb-textarea pr-12 h-14 py-4 resize-none"
            rows={1}
            disabled={isEscalated}
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || loading || isEscalated}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-primary-foreground disabled:opacity-40 hover:bg-primary/90 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </AppShell>
  );
}

// Simulated responses – replace with actual AI API call
function getSimulatedResponse(input: string): string {
  const lower = input.toLowerCase();
  if (lower.includes('stress') || lower.includes('qo\'rq') || lower.includes('tashvish')) {
    return "Stress – bu tabiiy hodisa. Bir necha nafas chuqur oling: 4 soniya nafas oling, 4 soniya ushlab turing, 4 soniya chiqaring. Bu texnikani 4-5 marta takrorlang. Shuningdek, sport, uyqu va yaqinlaringiz bilan suhbat juda yordam beradi. Agar stress uzoq vaqt davom etsa, psixolog bilan uchrashish foydali bo'ladi.";
  }
  if (lower.includes('uyqu') || lower.includes('sleep')) {
    return "Yaxshi uyqu uchun: har kuni bir xil vaqtda yoting va turing. Yotishdan 1 soat oldin ekranlardan uzoqlashing. Xona haroratini 18-20°C ga o'rnating. Qorong'i va jim xonada uxlang. Agar uyqusizlik 2 haftadan ortiq davom etsa, mutaxassisga murojaat qiling.";
  }
  if (lower.includes('do\'st') || lower.includes('munosabat') || lower.includes('ijtimoiy')) {
    return "Munosabatlar ba'zan qiyin bo'lishi mumkin. Birinchi qadam – ochiq va halol muloqot. Boshqalarni tinglash va o'z hissiyotlaringizni muloyimlik bilan ifodalash muhim. Agar biror narsadan ranjigan bo'lsangiz, 'Men ... his qilaman, chunki...' shaklida gapiring. Bu o'zaro tushunishga yordam beradi.";
  }
  return "Sizning his-tuyg'ularingiz ahamiyatli. Bu haqida ko'proq gapira olasizmi? Men sizni tinglashga tayyorman. Agar bu vaziyat jiddiy bo'lsa, professionaldan yordam so'rash eng to'g'ri qadam.";
}
