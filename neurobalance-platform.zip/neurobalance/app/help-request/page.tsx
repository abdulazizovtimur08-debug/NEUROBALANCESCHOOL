'use client';

import { useState } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import {
  Shield, CheckCircle2, AlertTriangle,
  ChevronDown,
} from 'lucide-react';
import type { UrgencyLevel, RequestCategory } from '@/types';

const URGENCY_LEVELS: UrgencyLevel[] = ['low', 'medium', 'high', 'critical'];
const CATEGORIES: RequestCategory[] = [
  'academic', 'social', 'family', 'emotional', 'behavioral', 'bullying', 'other',
];

const URGENCY_COLORS: Record<UrgencyLevel, string> = {
  low: 'border-calm-300 bg-calm-50 text-calm-700',
  medium: 'border-warm-300 bg-warm-50 text-warm-700',
  high: 'border-orange-300 bg-orange-50 text-orange-700',
  critical: 'border-red-400 bg-red-50 text-red-700',
};

export default function HelpRequestPage() {
  const { t } = useI18n();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('medium');
  const [category, setCategory] = useState<RequestCategory>('emotional');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // TODO: Save to Firestore via services/requests.ts
    await new Promise((r) => setTimeout(r, 1200));

    setLoading(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <AppShell>
        <div className="max-w-md mx-auto text-center py-16 fade-in space-y-6">
          <div className="w-20 h-20 rounded-full bg-calm-100 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10 text-calm-600" />
          </div>
          <div>
            <h1 className="nb-page-title mb-2">{t('helpRequest.submitted')}</h1>
            <p className="text-muted-foreground">{t('helpRequest.submittedMessage')}</p>
          </div>
          <a href="/dashboard" className="nb-btn-primary">
            Bosh sahifaga qaytish
          </a>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="max-w-xl mx-auto space-y-6 fade-in">
        {/* Header */}
        <div>
          <h1 className="nb-page-title mb-1">{t('helpRequest.title')}</h1>
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Shield className="w-4 h-4 text-calm-600" />
            {t('helpRequest.subtitle')}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Anonymous toggle */}
          <div className="nb-card p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">{t('helpRequest.form.anonymous')}</p>
                <p className="text-xs text-muted-foreground">{t('helpRequest.form.anonymousHint')}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsAnonymous(!isAnonymous)}
              className={`w-11 h-6 rounded-full transition-colors duration-200 ${
                isAnonymous ? 'bg-primary' : 'bg-border'
              }`}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 mx-0.5 ${
                  isAnonymous ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Title */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('helpRequest.form.title')} *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t('helpRequest.form.titlePlaceholder')}
              className="nb-input"
              required
            />
          </div>

          {/* Category */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('helpRequest.form.category')}</label>
            <div className="relative">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as RequestCategory)}
                className="nb-input appearance-none pr-8 cursor-pointer"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {t(`helpRequest.categories.${cat}`)}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            </div>
          </div>

          {/* Urgency */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('helpRequest.form.urgency')}</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {URGENCY_LEVELS.map((level) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setUrgency(level)}
                  className={`
                    px-3 py-2 rounded-xl border-2 text-sm font-medium transition-all
                    ${urgency === level ? URGENCY_COLORS[level] + ' border-current' : 'border-border text-muted-foreground hover:border-border/80'}
                  `}
                >
                  {level === 'critical' && <AlertTriangle className="w-3 h-3 inline mr-1" />}
                  {t(`helpRequest.urgencyLevels.${level}`)}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="nb-card p-5 space-y-3">
            <label className="nb-label">{t('helpRequest.form.description')} *</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t('helpRequest.form.descriptionPlaceholder')}
              className="nb-textarea h-36"
              required
            />
          </div>

          {/* Crisis notice */}
          {urgency === 'critical' && (
            <div className="flex items-start gap-3 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold">Muhim: </strong>
                Agar siz yoki boshqa kimdir xavf ostida bo'lsa, darhol psixolog yoki mutasaddi bilan bog'laning.
              </div>
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={loading || !title || !description}
            className="nb-btn-primary w-full"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Yuborilmoqda...
              </span>
            ) : (
              t('common.submit')
            )}
          </button>
        </form>
      </div>
    </AppShell>
  );
}
