'use client';

import { useState } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import {
  CalendarDays, Video, MapPin, Clock, CheckCircle,
  XCircle, AlertCircle, Loader,
} from 'lucide-react';
import type { SessionStatus, SessionFormat } from '@/types';

interface MockAppointment {
  id: string;
  date: string;
  time: string;
  psychologist: string;
  format: SessionFormat;
  status: SessionStatus;
  meetingUrl?: string;
  location?: string;
  duration: number;
}

const MOCK_APPOINTMENTS: MockAppointment[] = [
  {
    id: '1',
    date: '2025-03-12',
    time: '10:00',
    psychologist: 'Nilufar Karimova',
    format: 'online',
    status: 'confirmed',
    meetingUrl: 'https://meet.google.com/abc-def-ghi',
    duration: 50,
  },
  {
    id: '2',
    date: '2025-03-18',
    time: '14:30',
    psychologist: 'Nilufar Karimova',
    format: 'offline',
    status: 'pending',
    location: '208-xona, Asosiy bino',
    duration: 50,
  },
  {
    id: '3',
    date: '2025-02-28',
    time: '11:00',
    psychologist: 'Nilufar Karimova',
    format: 'online',
    status: 'completed',
    duration: 50,
  },
];

const STATUS_CONFIG: Record<
  SessionStatus,
  { icon: React.ComponentType<{ className?: string }>; color: string; bg: string }
> = {
  pending: { icon: Loader, color: 'text-muted-foreground', bg: 'bg-secondary' },
  confirmed: { icon: CheckCircle, color: 'text-calm-600', bg: 'bg-calm-50 border border-calm-200' },
  completed: { icon: CheckCircle, color: 'text-sage-600', bg: 'bg-sage-50 border border-sage-200' },
  canceled: { icon: XCircle, color: 'text-red-500', bg: 'bg-red-50 border border-red-200' },
};

function AppointmentCard({ appt, t }: { appt: MockAppointment; t: (k: string) => string }) {
  const config = STATUS_CONFIG[appt.status];
  const StatusIcon = config.icon;
  const isPast = appt.status === 'completed' || appt.status === 'canceled';
  const dateObj = new Date(`${appt.date}T${appt.time}`);
  const formattedDate = dateObj.toLocaleDateString('uz-UZ', {
    weekday: 'long', day: 'numeric', month: 'long',
  });

  return (
    <div className={`nb-card p-5 ${isPast ? 'opacity-70' : ''} transition-opacity`}>
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-2 flex-1">
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full ${config.bg} ${config.color}`}>
              <StatusIcon className="w-3 h-3" />
              {t(`schedule.status.${appt.status}`)}
            </span>
            <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${
              appt.format === 'online'
                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                : 'bg-sage-50 text-sage-700 border border-sage-200'
            }`}>
              {appt.format === 'online'
                ? <Video className="w-3 h-3" />
                : <MapPin className="w-3 h-3" />}
              {t(`schedule.format.${appt.format}`)}
            </span>
          </div>

          <div>
            <p className="font-medium text-foreground capitalize">{formattedDate}</p>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-0.5">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {appt.time}
              </span>
              <span>{appt.duration} {t('schedule.minutes')}</span>
              <span>{appt.psychologist}</span>
            </div>
          </div>

          {appt.format === 'online' && appt.meetingUrl && appt.status === 'confirmed' && (
            <a
              href={appt.meetingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors"
            >
              <Video className="w-3 h-3" />
              {t('schedule.meetingUrl')} →
            </a>
          )}

          {appt.format === 'offline' && appt.location && (
            <p className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="w-3 h-3" />
              {appt.location}
            </p>
          )}
        </div>

        {/* Cancel button for upcoming */}
        {!isPast && appt.status !== 'canceled' && (
          <button className="text-xs text-muted-foreground hover:text-destructive transition-colors px-2 py-1 rounded-lg hover:bg-destructive/10">
            {t('common.cancel')}
          </button>
        )}
      </div>
    </div>
  );
}

export default function SchedulePage() {
  const { t } = useI18n();
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming');

  const upcoming = MOCK_APPOINTMENTS.filter(
    (a) => a.status === 'confirmed' || a.status === 'pending',
  );
  const past = MOCK_APPOINTMENTS.filter(
    (a) => a.status === 'completed' || a.status === 'canceled',
  );

  const displayed = tab === 'upcoming' ? upcoming : past;

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto space-y-6 fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="nb-page-title mb-1">{t('schedule.title')}</h1>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <CalendarDays className="w-4 h-4" />
            {new Date().toLocaleDateString('uz-UZ', { weekday: 'long', day: 'numeric', month: 'long' })}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-secondary">
          {(['upcoming', 'past'] as const).map((tabKey) => (
            <button
              key={tabKey}
              onClick={() => setTab(tabKey)}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${
                tab === tabKey
                  ? 'bg-card text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {t(`schedule.${tabKey}`)}
            </button>
          ))}
        </div>

        {/* Appointments */}
        <div className="space-y-3">
          {displayed.length === 0 ? (
            <div className="nb-card p-10 text-center text-muted-foreground text-sm">
              <CalendarDays className="w-8 h-8 mx-auto mb-3 opacity-30" />
              {t('schedule.noAppointments')}
            </div>
          ) : (
            displayed.map((appt) => (
              <AppointmentCard key={appt.id} appt={appt} t={t} />
            ))
          )}
        </div>
      </div>
    </AppShell>
  );
}
