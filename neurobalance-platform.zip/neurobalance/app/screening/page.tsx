'use client';

import { useState, useMemo } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import { SCREENING_QUESTIONS } from '@/lib/screening-questions';
import { calculateScreeningScores, getScoreBg } from '@/lib/scoring-engine';
import type { ScreeningAnswer, AppLanguage } from '@/types';
import {
  CheckCircle2, ChevronRight, ChevronLeft, Shield, BarChart2,
} from 'lucide-react';

const TOTAL_STAGES = 3;

function ProgressBar({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex gap-2">
      {Array.from({ length: total }, (_, i) => (
        <div
          key={i}
          className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
            i < current ? 'bg-primary' : i === current ? 'bg-primary/40' : 'bg-border'
          }`}
        />
      ))}
    </div>
  );
}

function LikertScale({
  value,
  onChange,
  labels,
}: {
  value: number | null;
  onChange: (v: number) => void;
  labels: string[];
}) {
  return (
    <div className="space-y-3">
      <div className="flex gap-2 sm:gap-3">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            onClick={() => onChange(n)}
            className={`
              flex-1 aspect-square rounded-2xl border-2 text-sm font-semibold
              transition-all duration-150 active:scale-95
              ${
                value === n
                  ? 'border-primary bg-primary text-primary-foreground shadow-md scale-105'
                  : 'border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
              }
            `}
          >
            {n}
          </button>
        ))}
      </div>
      <div className="flex justify-between">
        <span className="text-xs text-muted-foreground">{labels[0]}</span>
        <span className="text-xs text-muted-foreground">{labels[4]}</span>
      </div>
    </div>
  );
}

function ResultCard({ score, label, indicator, t }: {
  score: number; label: string; indicator: string;
  t: (k: string) => string;
}) {
  return (
    <div className={`p-4 rounded-xl border ${getScoreBg(score)}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium">{t(`screening.indicators.${indicator}`)}</span>
        <span className="text-lg font-display font-semibold">{score}</span>
      </div>
      <div className="h-2 rounded-full bg-current/20 overflow-hidden">
        <div
          className="h-full rounded-full bg-current/60 transition-all duration-700"
          style={{ width: `${score}%` }}
        />
      </div>
      <div className="mt-1.5 text-xs font-medium">{t(`screening.labels.${label}`)}</div>
    </div>
  );
}

export default function ScreeningPage() {
  const { t, language } = useI18n();

  const [currentStage, setCurrentStage] = useState<1 | 2 | 3>(1);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [questionIndex, setQuestionIndex] = useState(0);

  const stageQuestions = useMemo(
    () => SCREENING_QUESTIONS.filter((q) => q.stage === currentStage).sort((a, b) => a.order - b.order),
    [currentStage],
  );

  const currentQuestion = stageQuestions[questionIndex];
  const currentAnswer = currentQuestion ? answers[currentQuestion.id] ?? null : null;

  const scaleLabels = [1, 2, 3, 4, 5].map((n) => t(`screening.scaleLabels.${n}`));

  const handleAnswer = (value: number) => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({ ...prev, [currentQuestion.id]: value }));
  };

  const handleNext = () => {
    if (questionIndex < stageQuestions.length - 1) {
      setQuestionIndex((i) => i + 1);
    } else if (currentStage < TOTAL_STAGES) {
      setCurrentStage((s) => (s + 1) as 1 | 2 | 3);
      setQuestionIndex(0);
    } else {
      setIsComplete(true);
    }
  };

  const handleBack = () => {
    if (questionIndex > 0) {
      setQuestionIndex((i) => i - 1);
    } else if (currentStage > 1) {
      const prevStage = (currentStage - 1) as 1 | 2 | 3;
      const prevQ = SCREENING_QUESTIONS.filter((q) => q.stage === prevStage);
      setCurrentStage(prevStage);
      setQuestionIndex(prevQ.length - 1);
    }
  };

  const allAnswers: ScreeningAnswer[] = Object.entries(answers).map(([questionId, value]) => ({
    questionId,
    value: value as 1 | 2 | 3 | 4 | 5,
  }));

  const results = isComplete ? calculateScreeningScores(allAnswers) : null;

  const totalQsCompleted = Object.keys(answers).length;
  const totalQuestions = SCREENING_QUESTIONS.length;

  if (isComplete && results) {
    return (
      <AppShell>
        <div className="max-w-2xl mx-auto fade-in space-y-6">
          <div className="text-center py-4">
            <div className="w-16 h-16 rounded-full bg-calm-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-calm-600" />
            </div>
            <h1 className="nb-page-title mb-2">{t('screening.results')}</h1>
            <p className="text-muted-foreground text-sm">
              Umumiy ball: <span className="font-semibold text-foreground">{results.totalScore}/100</span>
            </p>
          </div>

          {/* Risk badge */}
          <div className={`p-4 rounded-2xl text-center border nb-badge-risk-${results.riskLevel}`}>
            <p className="text-sm font-medium">
              {t(`screening.riskLevels.${results.riskLevel}`)}
            </p>
          </div>

          {/* Indicator scores */}
          <div>
            <h2 className="nb-section-title mb-4 flex items-center gap-2">
              <BarChart2 className="w-4 h-4" />
              Ko'rsatkichlar
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {results.indicatorScores.map((s) => (
                <ResultCard
                  key={s.indicator}
                  score={s.normalized}
                  label={s.label}
                  indicator={s.indicator}
                  t={t}
                />
              ))}
            </div>
          </div>

          {/* CTA */}
          {results.riskLevel === 'high' || results.riskLevel === 'critical' ? (
            <div className="nb-card p-5 border border-red-200 bg-red-50">
              <p className="text-red-700 text-sm font-medium mb-3">
                ⚠️ Psixolog bilan bog'lanish tavsiya etiladi
              </p>
              <a href="/help-request" className="nb-btn-primary text-sm">
                Yordam so'rash
              </a>
            </div>
          ) : (
            <div className="nb-card p-5 bg-calm-50 border border-calm-200">
              <p className="text-calm-700 text-sm mb-3">
                Natijalaringiz psixologga yuborildi. Qo'shimcha yordam kerak bo'lsa, murojaat qiling.
              </p>
              <a href="/dashboard" className="nb-btn-secondary text-sm">
                Bosh sahifaga
              </a>
            </div>
          )}
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="max-w-xl mx-auto space-y-6 fade-in">
        {/* Header */}
        <div>
          <h1 className="nb-page-title mb-1">{t('screening.title')}</h1>
          <p className="text-muted-foreground text-sm">{t('screening.subtitle')}</p>
        </div>

        {/* Stage progress */}
        <div className="nb-card p-4 space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">
              {t('screening.stage')} {currentStage} {t('screening.of')} {TOTAL_STAGES}
            </span>
            <span className="text-muted-foreground text-xs">
              {totalQsCompleted}/{totalQuestions} savol
            </span>
          </div>
          <ProgressBar current={currentStage - 1} total={TOTAL_STAGES} />
        </div>

        {/* Anonymous toggle */}
        <div className="nb-card p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">{t('screening.anonymous')}</p>
              <p className="text-xs text-muted-foreground">{t('screening.anonymousHint')}</p>
            </div>
          </div>
          <button
            onClick={() => setIsAnonymous(!isAnonymous)}
            className={`w-11 h-6 rounded-full transition-colors duration-200 ${
              isAnonymous ? 'bg-primary' : 'bg-border'
            }`}
          >
            <span
              className={`block w-5 h-5 rounded-full bg-white shadow-sm transform transition-transform duration-200 mx-0.5 ${
                isAnonymous ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Question card */}
        {currentQuestion && (
          <div className="nb-card p-6 space-y-6">
            <div>
              <p className="nb-label mb-2">
                {t('screening.question')} {questionIndex + 1}/{stageQuestions.length}
              </p>
              <h2 className="text-lg font-medium text-foreground leading-relaxed">
                {currentQuestion.text[language as AppLanguage]}
              </h2>
            </div>

            <LikertScale
              value={currentAnswer}
              onChange={handleAnswer}
              labels={scaleLabels}
            />

            {/* Navigation */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={handleBack}
                disabled={currentStage === 1 && questionIndex === 0}
                className="nb-btn-ghost disabled:opacity-30"
              >
                <ChevronLeft className="w-4 h-4" />
                {t('common.back')}
              </button>

              <button
                onClick={handleNext}
                disabled={currentAnswer === null}
                className="nb-btn-primary disabled:opacity-40"
              >
                {currentStage === TOTAL_STAGES && questionIndex === stageQuestions.length - 1
                  ? t('screening.finish')
                  : t('common.next')}
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
