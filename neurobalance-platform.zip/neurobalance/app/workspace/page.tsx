'use client';

import { useState } from 'react';
import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import {
  Inbox, UserCheck, CheckSquare, Clock,
  ChevronRight, AlertTriangle, Search, Filter,
} from 'lucide-react';

// Mock data – replace with Firestore queries
const MOCK_CASES = [
  {
    id: '1',
    name: 'Anon',
    isAnonymous: true,
    urgency: 'high',
    category: 'emotional',
    status: 'open',
    createdAt: '2 soat oldin',
    preview: "O'zim haqimda yaxshi o'ylay olmayman...",
    riskLevel: 'moderate',
  },
  {
    id: '2',
    name: 'Jasur M.',
    isAnonymous: false,
    urgency: 'medium',
    category: 'academic',
    status: 'assigned',
    createdAt: '1 kun oldin',
    preview: 'Imtihonlardan qo\'rqaman...',
    riskLevel: 'low',
  },
  {
    id: '3',
    name: 'Anon',
    isAnonymous: true,
    urgency: 'critical',
    category: 'bullying',
    status: 'open',
    createdAt: '3 soat oldin',
    preview: 'Sinfdoshlarim meni bezovta qilyapti...',
    riskLevel: 'high',
  },
  {
    id: '4',
    name: 'Nodira K.',
    isAnonymous: false,
    urgency: 'low',
    category: 'social',
    status: 'in_progress',
    createdAt: '2 kun oldin',
    preview: "Do'stlarim bilan muloqot qiyin bo'lmoqda...",
    riskLevel: 'none',
  },
];

const URGENCY_COLORS: Record<string, string> = {
  low: 'bg-calm-100 text-calm-700',
  medium: 'bg-warm-100 text-warm-700',
  high: 'bg-orange-100 text-orange-700',
  critical: 'bg-red-100 text-red-700',
};

const RISK_COLORS: Record<string, string> = {
  none: 'nb-badge-risk-none',
  low: 'nb-badge-risk-low',
  moderate: 'nb-badge-risk-moderate',
  high: 'nb-badge-risk-high',
  critical: 'nb-badge-risk-critical',
};

export default function WorkspacePage() {
  const { t } = useI18n();
  const [activeTab, setActiveTab] = useState<'new' | 'active' | 'completed'>('new');
  const [search, setSearch] = useState('');
  const [selectedCase, setSelectedCase] = useState<string | null>(null);

  const stats = [
    { icon: Inbox, label: t('workspace.newCases'), value: 3, color: 'text-warm-600' },
    { icon: UserCheck, label: t('workspace.activeCases'), value: 6, color: 'text-calm-600' },
    { icon: CheckSquare, label: t('workspace.completedCases'), value: 24, color: 'text-sage-600' },
    { icon: Clock, label: t('workspace.pendingFollowUps'), value: 2, color: 'text-orange-600' },
  ];

  const filteredCases = MOCK_CASES.filter((c) => {
    const matchSearch = !search || c.preview.toLowerCase().includes(search.toLowerCase());
    const matchTab =
      activeTab === 'new' ? c.status === 'open'
      : activeTab === 'active' ? c.status === 'assigned' || c.status === 'in_progress'
      : c.status === 'resolved';
    return matchSearch && matchTab;
  });

  return (
    <AppShell>
      <div className="space-y-6 fade-in">
        {/* Header */}
        <div>
          <h1 className="nb-page-title mb-1">{t('workspace.title')}</h1>
          <p className="text-muted-foreground text-sm">Bugungi sana: {new Date().toLocaleDateString('uz')}</p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {stats.map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="nb-card p-4 stagger-1 fade-in">
              <div className="flex items-center gap-2 mb-1">
                <Icon className={`w-4 h-4 ${color}`} />
                <span className="nb-label text-[10px]">{label}</span>
              </div>
              <p className={`text-3xl font-display font-semibold ${color}`}>{value}</p>
            </div>
          ))}
        </div>

        {/* Cases panel */}
        <div className="nb-card overflow-hidden stagger-2 fade-in">
          {/* Tabs */}
          <div className="flex border-b border-border/60">
            {(['new', 'active', 'completed'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${
                  activeTab === tab
                    ? 'text-primary border-b-2 border-primary bg-primary/5'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab === 'new' ? t('workspace.newCases')
                  : tab === 'active' ? t('workspace.activeCases')
                  : t('workspace.completedCases')}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="p-4 border-b border-border/60">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t('common.search') + '...'}
                className="nb-input pl-9"
              />
            </div>
          </div>

          {/* Case list */}
          <div className="divide-y divide-border/40">
            {filteredCases.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground text-sm">
                {t('common.noData')}
              </div>
            ) : (
              filteredCases.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCase(c.id === selectedCase ? null : c.id)}
                  className="w-full text-left p-4 hover:bg-secondary/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm text-foreground">
                          {c.isAnonymous ? 'Anonim' : c.name}
                        </span>
                        {c.urgency === 'critical' && (
                          <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                        )}
                        <span className={`text-xs px-2 py-0.5 rounded-full ${URGENCY_COLORS[c.urgency]}`}>
                          {t(`helpRequest.urgencyLevels.${c.urgency}`)}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{c.preview}</p>
                      <div className="flex items-center gap-3 mt-1.5">
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${RISK_COLORS[c.riskLevel]}`}>
                          {t(`screening.riskLevels.${c.riskLevel}`)}
                        </span>
                        <span className="text-xs text-muted-foreground">{c.createdAt}</span>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${selectedCase === c.id ? 'rotate-90' : ''}`} />
                  </div>

                  {/* Expanded actions */}
                  {selectedCase === c.id && (
                    <div className="mt-3 pt-3 border-t border-border/40 flex flex-wrap gap-2">
                      <a href={`/schedule?clientId=${c.id}`} className="nb-btn-primary text-xs py-1.5 px-3">
                        {t('workspace.scheduleSession')}
                      </a>
                      <a href={`/notes?caseId=${c.id}`} className="nb-btn-secondary text-xs py-1.5 px-3">
                        {t('workspace.writeNote')}
                      </a>
                      <button className="nb-btn-ghost text-xs py-1.5 px-3">
                        {t('workspace.screeningResults')}
                      </button>
                    </div>
                  )}
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
