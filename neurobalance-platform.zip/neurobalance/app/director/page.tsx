'use client';

import { AppShell } from '@/components/shared/AppShell';
import { useI18n } from '@/lib/i18n';
import {
  AreaChart, Area, BarChart, Bar, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { Shield, TrendingUp, TrendingDown, Minus } from 'lucide-react';

// Mock data – in production fetched from Firestore aggregation
const MONTHLY_SESSIONS = [
  { month: 'Sep', sessions: 18, resolved: 14 },
  { month: 'Oct', sessions: 24, resolved: 20 },
  { month: 'Nov', sessions: 31, resolved: 26 },
  { month: 'Dec', sessions: 22, resolved: 18 },
  { month: 'Jan', sessions: 28, resolved: 25 },
  { month: 'Feb', sessions: 35, resolved: 30 },
  { month: 'Mar', sessions: 29, resolved: 24 },
];

const INDICATOR_TRENDS = [
  { month: 'Sep', mood: 62, stress: 55, social: 70, sleep: 68, relationship: 66 },
  { month: 'Oct', mood: 65, stress: 52, social: 72, sleep: 70, relationship: 68 },
  { month: 'Nov', mood: 60, stress: 58, social: 68, sleep: 65, relationship: 64 },
  { month: 'Dec', mood: 63, stress: 54, social: 71, sleep: 67, relationship: 65 },
  { month: 'Jan', mood: 68, stress: 50, social: 74, sleep: 72, relationship: 70 },
  { month: 'Feb', mood: 70, stress: 48, social: 76, sleep: 74, relationship: 71 },
  { month: 'Mar', mood: 72, stress: 46, social: 78, sleep: 73, relationship: 73 },
];

const RADAR_DATA = [
  { indicator: 'Kayfiyat', value: 72 },
  { indicator: 'Stress', value: 54 },
  { indicator: 'Ijtimoiy', value: 78 },
  { indicator: 'Uyqu', value: 73 },
  { indicator: 'Munosabat', value: 73 },
];

const PSYCHOLOGIST_WORKLOAD = [
  { name: 'Psix. A', sessions: 45, rating: 4.8 },
  { name: 'Psix. B', sessions: 38, rating: 4.6 },
  { name: 'Psix. C', sessions: 52, rating: 4.7 },
];

function KPICard({
  label, value, unit, trend, trendValue, color,
}: {
  label: string; value: number | string; unit?: string;
  trend?: 'up' | 'down' | 'flat'; trendValue?: string; color?: string;
}) {
  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;
  const trendColor = trend === 'up' ? 'text-calm-600' : trend === 'down' ? 'text-red-500' : 'text-muted-foreground';

  return (
    <div className="nb-card p-5 space-y-1 stagger-1 fade-in">
      <p className="nb-label">{label}</p>
      <div className="flex items-end gap-2">
        <span className={`text-3xl font-display font-semibold ${color ?? 'text-foreground'}`}>
          {value}
        </span>
        {unit && <span className="text-sm text-muted-foreground mb-1">{unit}</span>}
      </div>
      {trend && trendValue && (
        <div className={`flex items-center gap-1 text-xs ${trendColor}`}>
          <TrendIcon className="w-3 h-3" />
          {trendValue} oldingi oydan
        </div>
      )}
    </div>
  );
}

export default function DirectorDashboardPage() {
  const { t } = useI18n();

  return (
    <AppShell>
      <div className="space-y-8 fade-in">
        {/* Header */}
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="nb-page-title mb-1">{t('director.title')}</h1>
            <p className="text-muted-foreground text-sm">{t('director.subtitle')}</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-calm-50 border border-calm-200 text-calm-700 text-xs font-medium">
            <Shield className="w-3 h-3" />
            {t('director.anonymizedNote')}
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <KPICard
            label={t('director.kpis.totalSessions')} value={187}
            trend="up" trendValue="+12%"
            color="text-calm-700"
          />
          <KPICard
            label={t('director.kpis.averageRating')} value="4.7"
            unit="/5" trend="up" trendValue="+0.2"
            color="text-warm-600"
          />
          <KPICard
            label={t('director.kpis.resolvedCases')} value={142}
            trend="up" trendValue="+8%"
            color="text-sage-700"
          />
          <KPICard
            label={t('director.kpis.highRiskAlerts')} value={5}
            trend="down" trendValue="-3"
            color="text-orange-600"
          />
          <KPICard
            label={t('director.kpis.participationRate')} value={78}
            unit="%" trend="up" trendValue="+5%"
            color="text-calm-600"
          />
          <KPICard
            label={t('director.kpis.activeCases')} value={24}
            trend="flat" trendValue="=0"
            color="text-foreground"
          />
        </div>

        {/* Charts grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Sessions by month */}
          <div className="nb-card p-5 stagger-2 fade-in">
            <h2 className="nb-section-title mb-4">{t('director.charts.sessionsByMonth')}</h2>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={MONTHLY_SESSIONS} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                <Tooltip
                  contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 12 }}
                />
                <Bar dataKey="sessions" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Jami" />
                <Bar dataKey="resolved" fill="hsl(161 42% 68%)" radius={[4, 4, 0, 0]} name="Hal qilingan" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Screening trends */}
          <div className="nb-card p-5 stagger-3 fade-in">
            <h2 className="nb-section-title mb-4">{t('director.charts.screeningTrends')}</h2>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={INDICATOR_TRENDS} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="moodGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis domain={[40, 90]} tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                <Tooltip
                  contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 12 }}
                />
                <Area type="monotone" dataKey="mood" stroke="hsl(var(--primary))" fill="url(#moodGrad)" strokeWidth={2} name="Kayfiyat" />
                <Area type="monotone" dataKey="sleep" stroke="#93a67d" fill="transparent" strokeWidth={2} name="Uyqu" />
                <Area type="monotone" dataKey="social" stroke="#d98c3c" fill="transparent" strokeWidth={2} name="Ijtimoiy" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Radar – indicator breakdown */}
          <div className="nb-card p-5 stagger-4 fade-in">
            <h2 className="nb-section-title mb-4">{t('director.charts.indicatorBreakdown')}</h2>
            <div className="flex justify-center">
              <ResponsiveContainer width="100%" height={220}>
                <RadarChart data={RADAR_DATA}>
                  <PolarGrid stroke="hsl(var(--border))" />
                  <PolarAngleAxis dataKey="indicator" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                  <Radar name="O'rtacha ball" dataKey="value" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.25} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Psychologist workload */}
          <div className="nb-card p-5 stagger-5 fade-in">
            <h2 className="nb-section-title mb-4">{t('director.charts.psychologistWorkload')}</h2>
            <div className="space-y-4">
              {PSYCHOLOGIST_WORKLOAD.map((p) => (
                <div key={p.name}>
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="font-medium">{p.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-muted-foreground">{p.sessions} seans</span>
                      <span className="text-warm-600 font-medium">★ {p.rating}</span>
                    </div>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div
                      className="h-full rounded-full bg-primary/70 transition-all duration-700"
                      style={{ width: `${(p.sessions / 60) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              * Psixologlar nomi anonim ko'rinishda ko'rsatilgan
            </p>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
