// ============================================================
// CORE ENUMS
// ============================================================

export type UserRole = 'student' | 'staff' | 'psychologist' | 'director' | 'admin';

export type AppLanguage = 'uz' | 'ru' | 'en';

export type SessionStatus = 'pending' | 'confirmed' | 'completed' | 'canceled';

export type SessionFormat = 'online' | 'offline';

export type UrgencyLevel = 'low' | 'medium' | 'high' | 'critical';

export type RiskLevel = 'none' | 'low' | 'moderate' | 'high' | 'critical';

export type RequestCategory =
  | 'academic'
  | 'social'
  | 'family'
  | 'emotional'
  | 'behavioral'
  | 'bullying'
  | 'other';

export type NotificationType =
  | 'new_request'
  | 'appointment_reminder'
  | 'session_confirmed'
  | 'session_canceled'
  | 'follow_up_reminder'
  | 'high_risk_alert'
  | 'feedback_received';

// ============================================================
// USER & AUTH
// ============================================================

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  schoolId: string;
  avatarUrl?: string;
  language: AppLanguage;
  grade?: string;           // for students
  department?: string;      // for staff
  specialization?: string;  // for psychologists
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
}

// ============================================================
// SCREENING MODULE
// ============================================================

export interface ScreeningQuestion {
  id: string;
  stage: 1 | 2 | 3;
  indicator: 'mood' | 'stress' | 'social' | 'sleep' | 'relationship';
  order: number;
  text: Record<AppLanguage, string>;
  isReverse?: boolean; // reverse-scored question
}

export interface ScreeningAnswer {
  questionId: string;
  value: 1 | 2 | 3 | 4 | 5;
}

export interface ScreeningIndicatorScore {
  indicator: string;
  raw: number;
  normalized: number; // 0–100
  label: 'excellent' | 'good' | 'moderate' | 'poor' | 'critical';
}

export interface ScreeningResult {
  id: string;
  userId: string;
  schoolId: string;
  isAnonymous: boolean;
  stage: 1 | 2 | 3;
  answers: ScreeningAnswer[];
  indicatorScores: ScreeningIndicatorScore[];
  totalScore: number; // 0–100
  riskLevel: RiskLevel;
  completedAt: Date;
  language: AppLanguage;
}

// ============================================================
// HELP REQUEST MODULE
// ============================================================

export interface HelpRequest {
  id: string;
  authorId: string;
  schoolId: string;
  isAnonymous: boolean;
  title: string;
  description: string;
  urgency: UrgencyLevel;
  category: RequestCategory;
  status: 'open' | 'assigned' | 'in_progress' | 'resolved' | 'closed';
  assignedPsychologistId?: string;
  createdAt: Date;
  updatedAt: Date;
  resolvedAt?: Date;
}

// ============================================================
// SCHEDULING MODULE
// ============================================================

export interface Appointment {
  id: string;
  requestId?: string;
  studentId: string;           // student OR staff uid
  psychologistId: string;
  schoolId: string;
  scheduledAt: Date;
  durationMinutes: number;
  format: SessionFormat;
  meetingUrl?: string;         // for online sessions
  location?: string;           // for offline sessions
  status: SessionStatus;
  reminderSentAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  notes?: string;              // short public note for context (not session notes)
}

// ============================================================
// SESSION NOTES MODULE
// ============================================================

export interface SessionNote {
  id: string;
  appointmentId: string;
  psychologistId: string;
  clientId: string;
  schoolId: string;
  summary: string;
  recommendations: string;
  followUpNeeded: boolean;
  followUpDate?: Date;
  riskLevel: RiskLevel;
  createdAt: Date;
  updatedAt: Date;
  // PRIVATE: never exposed to directors, students, or staff
}

// ============================================================
// FEEDBACK MODULE
// ============================================================

export interface SessionFeedback {
  id: string;
  appointmentId: string;
  authorId: string;
  psychologistId: string;
  schoolId: string;
  rating: 1 | 2 | 3 | 4 | 5;
  comment?: string;
  isAnonymous: boolean;
  createdAt: Date;
}

// ============================================================
// NOTIFICATIONS
// ============================================================

export interface Notification {
  id: string;
  recipientId: string;
  schoolId: string;
  type: NotificationType;
  title: Record<AppLanguage, string>;
  body: Record<AppLanguage, string>;
  referenceId?: string;    // appointmentId, requestId, etc.
  referenceType?: string;
  isRead: boolean;
  createdAt: Date;
}

// ============================================================
// KPI / ANALYTICS
// ============================================================

export interface SchoolKPI {
  schoolId: string;
  period: string;           // e.g. "2024-Q1"
  totalSessions: number;
  completedSessions: number;
  canceledSessions: number;
  averageRating: number;
  resolvedRequests: number;
  openRequests: number;
  highRiskAlerts: number;
  averageScreeningScore: number;
  screeningParticipationRate: number;
  psychologistWorkload: PsychologistWorkload[];
  indicatorTrends: IndicatorTrend[];
}

export interface PsychologistWorkload {
  psychologistId: string;
  displayName: string;       // anonymized in director view?
  totalSessions: number;
  completedSessions: number;
  averageRating: number;
  resolvedCases: number;
}

export interface IndicatorTrend {
  indicator: string;
  monthlyAverages: { month: string; average: number }[];
}

// ============================================================
// SCHOOL (Multi-tenant)
// ============================================================

export interface School {
  id: string;
  name: string;
  city: string;
  country: string;
  plan: 'basic' | 'standard' | 'premium';
  adminIds: string[];
  psychologistIds: string[];
  createdAt: Date;
  isActive: boolean;
  settings: SchoolSettings;
}

export interface SchoolSettings {
  defaultLanguage: AppLanguage;
  allowAnonymousScreening: boolean;
  allowAnonymousRequests: boolean;
  screeningFrequencyDays: number;
  notificationsEnabled: boolean;
  aiAdvisorEnabled: boolean;
}

// ============================================================
// AI ADVISOR
// ============================================================

export interface AIAdvisorSession {
  id: string;
  userId: string;
  schoolId: string;
  screeningResultId?: string;
  messages: AIMessage[];
  isEscalated: boolean;       // true if high-risk detected
  createdAt: Date;
  updatedAt: Date;
}

export interface AIMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isEscalationNotice?: boolean;
}

// ============================================================
// FORM TYPES
// ============================================================

export interface SignInFormData {
  email: string;
  password: string;
}

export interface HelpRequestFormData {
  title: string;
  description: string;
  urgency: UrgencyLevel;
  category: RequestCategory;
  isAnonymous: boolean;
}

export interface AppointmentFormData {
  clientId: string;
  scheduledAt: Date;
  durationMinutes: number;
  format: SessionFormat;
  meetingUrl?: string;
  location?: string;
  notes?: string;
}

export interface SessionNoteFormData {
  summary: string;
  recommendations: string;
  followUpNeeded: boolean;
  followUpDate?: Date;
  riskLevel: RiskLevel;
}

export interface FeedbackFormData {
  rating: 1 | 2 | 3 | 4 | 5;
  comment?: string;
  isAnonymous: boolean;
}
