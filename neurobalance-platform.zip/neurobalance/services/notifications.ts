import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { NotificationType, AppLanguage } from '@/types';

// ──────────────────────────────────────────────────────────────────────────────
// Notification templates for each type
// ──────────────────────────────────────────────────────────────────────────────

const NOTIFICATION_TEMPLATES: Record<
  NotificationType,
  { title: Record<AppLanguage, string>; body: Record<AppLanguage, string> }
> = {
  new_request: {
    title: {
      uz: 'Yangi yordam so\'rovi',
      ru: 'Новый запрос о помощи',
      en: 'New Help Request',
    },
    body: {
      uz: 'Yangi maxfiy so\'rov qabul qilindi',
      ru: 'Получен новый конфиденциальный запрос',
      en: 'A new confidential request has been received',
    },
  },
  appointment_reminder: {
    title: {
      uz: 'Seans eslatmasi',
      ru: 'Напоминание о сеансе',
      en: 'Session Reminder',
    },
    body: {
      uz: 'Seansga 1 soat qoldi',
      ru: 'До сеанса 1 час',
      en: 'Your session starts in 1 hour',
    },
  },
  session_confirmed: {
    title: {
      uz: 'Seans tasdiqlandi',
      ru: 'Сеанс подтверждён',
      en: 'Session Confirmed',
    },
    body: {
      uz: 'Seanschangiz psixolog tomonidan tasdiqlandi',
      ru: 'Ваш сеанс подтверждён психологом',
      en: 'Your session has been confirmed by the psychologist',
    },
  },
  session_canceled: {
    title: {
      uz: 'Seans bekor qilindi',
      ru: 'Сеанс отменён',
      en: 'Session Canceled',
    },
    body: {
      uz: 'Seanschangiz bekor qilindi',
      ru: 'Ваш сеанс был отменён',
      en: 'Your session has been canceled',
    },
  },
  follow_up_reminder: {
    title: {
      uz: 'Kuzatuv eslatmasi',
      ru: 'Напоминание о наблюдении',
      en: 'Follow-up Reminder',
    },
    body: {
      uz: 'Mijozingizning kuzatuv sanasi yetib keldi',
      ru: 'Наступила дата наблюдения за вашим клиентом',
      en: "Your client's follow-up date has arrived",
    },
  },
  high_risk_alert: {
    title: {
      uz: '⚠️ Yuqori xavf ogohlantirishi',
      ru: '⚠️ Предупреждение о высоком риске',
      en: '⚠️ High Risk Alert',
    },
    body: {
      uz: 'Yuqori xavf darajasidagi skreening natijasi aniqlandi',
      ru: 'Обнаружен результат скрининга с высоким уровнем риска',
      en: 'A high-risk screening result has been detected',
    },
  },
  feedback_received: {
    title: {
      uz: 'Fikr-mulohaza qabul qilindi',
      ru: 'Получен отзыв',
      en: 'Feedback Received',
    },
    body: {
      uz: 'Seans uchun yangi baho qoldirildi',
      ru: 'Получена новая оценка за сеанс',
      en: 'A new rating has been left for your session',
    },
  },
};

// ──────────────────────────────────────────────────────────────────────────────
// Send notification (writes to Firestore; FCM push can be triggered via
// Cloud Functions watching this collection)
// ──────────────────────────────────────────────────────────────────────────────

export async function sendNotification({
  recipientId,
  schoolId,
  type,
  referenceId,
  referenceType,
}: {
  recipientId: string;
  schoolId: string;
  type: NotificationType;
  referenceId?: string;
  referenceType?: string;
}) {
  const template = NOTIFICATION_TEMPLATES[type];

  await addDoc(collection(db, 'notifications'), {
    recipientId,
    schoolId,
    type,
    title: template.title,
    body: template.body,
    referenceId: referenceId ?? null,
    referenceType: referenceType ?? null,
    isRead: false,
    createdAt: serverTimestamp(),
  });
}

// Convenience wrappers

export const notifyNewRequest = (recipientId: string, schoolId: string, requestId: string) =>
  sendNotification({ recipientId, schoolId, type: 'new_request', referenceId: requestId, referenceType: 'request' });

export const notifyAppointmentReminder = (recipientId: string, schoolId: string, appointmentId: string) =>
  sendNotification({ recipientId, schoolId, type: 'appointment_reminder', referenceId: appointmentId, referenceType: 'appointment' });

export const notifySessionConfirmed = (recipientId: string, schoolId: string, appointmentId: string) =>
  sendNotification({ recipientId, schoolId, type: 'session_confirmed', referenceId: appointmentId, referenceType: 'appointment' });

export const notifySessionCanceled = (recipientId: string, schoolId: string, appointmentId: string) =>
  sendNotification({ recipientId, schoolId, type: 'session_canceled', referenceId: appointmentId, referenceType: 'appointment' });

export const notifyHighRisk = (recipientId: string, schoolId: string, screeningId: string) =>
  sendNotification({ recipientId, schoolId, type: 'high_risk_alert', referenceId: screeningId, referenceType: 'screening' });

export const notifyFeedbackReceived = (recipientId: string, schoolId: string, feedbackId: string) =>
  sendNotification({ recipientId, schoolId, type: 'feedback_received', referenceId: feedbackId, referenceType: 'feedback' });
