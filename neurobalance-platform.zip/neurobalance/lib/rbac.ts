import type { UserRole } from '@/types';

// ──────────────────────────────────────────────────────────────────────────────
// Role-Based Access Control Matrix
// ──────────────────────────────────────────────────────────────────────────────

export type Permission =
  // Screening
  | 'screening:take'
  | 'screening:view_own'
  | 'screening:view_all'           // psychologist sees results for their clients
  | 'screening:view_aggregate'     // director sees only aggregate data
  // Help Requests
  | 'request:create'
  | 'request:view_own'
  | 'request:view_assigned'
  | 'request:view_all'
  | 'request:assign'
  | 'request:resolve'
  // Appointments
  | 'appointment:create'           // psychologist creates
  | 'appointment:view_own'         // student/staff see their appointments
  | 'appointment:view_all'         // psychologist sees all their appointments
  | 'appointment:cancel'
  | 'appointment:confirm'
  // Session Notes (PRIVATE)
  | 'note:create'
  | 'note:view_own'                // psychologist sees notes they wrote
  | 'note:view_assigned'           // senior psychologist
  // Feedback
  | 'feedback:create'
  | 'feedback:view_own'            // psychologist sees their feedback
  | 'feedback:view_aggregate'      // director sees aggregate only
  // KPI / Director
  | 'kpi:view'
  | 'analytics:view_aggregate'
  // Users & Admin
  | 'user:manage'
  | 'school:manage'
  // Notifications
  | 'notification:receive_requests'
  | 'notification:receive_reminders'
  | 'notification:receive_risk_alerts'
  // AI Advisor
  | 'ai_advisor:use';

const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  student: [
    'screening:take',
    'screening:view_own',
    'request:create',
    'request:view_own',
    'appointment:view_own',
    'appointment:cancel',
    'feedback:create',
    'notification:receive_reminders',
    'ai_advisor:use',
  ],
  staff: [
    'screening:take',
    'screening:view_own',
    'request:create',
    'request:view_own',
    'appointment:view_own',
    'appointment:cancel',
    'feedback:create',
    'notification:receive_reminders',
    'ai_advisor:use',
  ],
  psychologist: [
    'screening:take',
    'screening:view_own',
    'screening:view_all',
    'request:view_assigned',
    'request:view_all',
    'request:assign',
    'request:resolve',
    'appointment:create',
    'appointment:view_own',
    'appointment:view_all',
    'appointment:cancel',
    'appointment:confirm',
    'note:create',
    'note:view_own',
    'feedback:view_own',
    'notification:receive_requests',
    'notification:receive_reminders',
    'notification:receive_risk_alerts',
    'ai_advisor:use',
  ],
  director: [
    'screening:view_aggregate',
    'feedback:view_aggregate',
    'kpi:view',
    'analytics:view_aggregate',
    'notification:receive_risk_alerts',
  ],
  admin: [
    'screening:take',
    'screening:view_own',
    'screening:view_all',
    'request:create',
    'request:view_own',
    'request:view_all',
    'appointment:create',
    'appointment:view_own',
    'appointment:view_all',
    'appointment:cancel',
    'appointment:confirm',
    'note:create',
    'note:view_own',
    'note:view_assigned',
    'feedback:create',
    'feedback:view_own',
    'feedback:view_aggregate',
    'kpi:view',
    'analytics:view_aggregate',
    'user:manage',
    'school:manage',
    'notification:receive_requests',
    'notification:receive_reminders',
    'notification:receive_risk_alerts',
    'ai_advisor:use',
  ],
};

export function hasPermission(role: UserRole, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

export function getUserPermissions(role: UserRole): Permission[] {
  return ROLE_PERMISSIONS[role] ?? [];
}

// ──────────────────────────────────────────────────────────────────────────────
// Navigation items per role
// ──────────────────────────────────────────────────────────────────────────────

export interface NavItem {
  key: string;
  href: string;
  icon: string;
  roles: UserRole[];
}

export const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard',     href: '/dashboard',     icon: 'LayoutDashboard', roles: ['student', 'staff', 'psychologist', 'director', 'admin'] },
  { key: 'screening',     href: '/screening',     icon: 'ClipboardList',   roles: ['student', 'staff', 'psychologist', 'admin'] },
  { key: 'helpRequest',   href: '/help-request',  icon: 'HeartHandshake',  roles: ['student', 'staff', 'admin'] },
  { key: 'schedule',      href: '/schedule',      icon: 'CalendarDays',    roles: ['student', 'staff', 'psychologist', 'admin'] },
  { key: 'workspace',     href: '/workspace',     icon: 'Stethoscope',     roles: ['psychologist', 'admin'] },
  { key: 'sessionNotes',  href: '/notes',         icon: 'FileText',        roles: ['psychologist', 'admin'] },
  { key: 'feedback',      href: '/feedback',      icon: 'Star',            roles: ['student', 'staff', 'psychologist', 'admin'] },
  { key: 'director',      href: '/director',      icon: 'BarChart3',       roles: ['director', 'admin'] },
  { key: 'aiAdvisor',     href: '/ai-advisor',    icon: 'Bot',             roles: ['student', 'staff', 'psychologist', 'admin'] },
  { key: 'profile',       href: '/profile',       icon: 'User',            roles: ['student', 'staff', 'psychologist', 'director', 'admin'] },
];

export function getNavItemsForRole(role: UserRole): NavItem[] {
  return NAV_ITEMS.filter((item) => item.roles.includes(role));
}
