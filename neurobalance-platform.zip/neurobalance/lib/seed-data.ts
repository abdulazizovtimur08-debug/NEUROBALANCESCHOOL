/**
 * NeuroBalance – Firestore Schema & Seed Data
 *
 * COLLECTION STRUCTURE
 * ──────────────────────────────────────────────────────────────────────────────
 *
 * /schools/{schoolId}
 *   - id, name, city, country, plan
 *   - adminIds[], psychologistIds[]
 *   - settings: { defaultLanguage, allowAnonymousScreening, ... }
 *
 * /users/{uid}
 *   - uid, email, displayName, role
 *   - schoolId, language
 *   - grade? (students), department? (staff), specialization? (psychologists)
 *   - createdAt, updatedAt, isActive
 *
 * /screeningResults/{resultId}
 *   - userId (null if anonymous), schoolId
 *   - isAnonymous, stage, answers[]
 *   - indicatorScores[], totalScore, riskLevel
 *   - completedAt, language
 *   SECURITY: read by owner uid OR psychologist with same schoolId
 *
 * /helpRequests/{requestId}
 *   - authorId (null if anonymous), schoolId
 *   - isAnonymous, title, description, urgency, category, status
 *   - assignedPsychologistId?, createdAt, updatedAt, resolvedAt?
 *   SECURITY: read by owner uid OR assigned psychologist OR admin
 *
 * /appointments/{appointmentId}
 *   - studentId, psychologistId, schoolId
 *   - requestId?, scheduledAt, durationMinutes
 *   - format (online/offline), meetingUrl?, location?
 *   - status, reminderSentAt?, createdAt, updatedAt
 *   SECURITY: read by studentId OR psychologistId OR admin
 *
 * /sessionNotes/{noteId}    ← STRICTLY PRIVATE
 *   - appointmentId, psychologistId, clientId, schoolId
 *   - summary, recommendations, followUpNeeded, followUpDate?
 *   - riskLevel, createdAt, updatedAt
 *   SECURITY: read ONLY by psychologistId (never by director/student/staff)
 *
 * /feedback/{feedbackId}
 *   - appointmentId, authorId, psychologistId, schoolId
 *   - rating (1-5), comment?, isAnonymous
 *   - createdAt
 *   SECURITY: read by psychologistId (individual); director sees aggregates via Cloud Functions
 *
 * /notifications/{notificationId}
 *   - recipientId, schoolId, type, title{}, body{}
 *   - referenceId?, referenceType?
 *   - isRead, createdAt
 *   SECURITY: read ONLY by recipientId
 *
 * /schoolKPIs/{schoolId_period}
 *   - schoolId, period (e.g. "2024-Q1")
 *   - totalSessions, completedSessions, canceledSessions
 *   - averageRating, resolvedRequests, openRequests
 *   - highRiskAlerts, averageScreeningScore, screeningParticipationRate
 *   - psychologistWorkload[] (anonymized), indicatorTrends[]
 *   SECURITY: read by director/admin of same schoolId
 *   WRITE: Cloud Functions only
 */

// ──────────────────────────────────────────────────────────────────────────────
// SEED DATA FUNCTION (run once to populate demo data)
// ──────────────────────────────────────────────────────────────────────────────

import {
  doc, setDoc, addDoc, collection,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';

export async function seedDemoData() {
  const schoolId = 'demo-school-001';

  // ── School ────────────────────────────────────────────────────────
  await setDoc(doc(db, 'schools', schoolId), {
    id: schoolId,
    name: 'Demo Maktab №1',
    city: 'Toshkent',
    country: 'UZ',
    plan: 'standard',
    adminIds: ['admin-001'],
    psychologistIds: ['psych-001'],
    createdAt: Timestamp.now(),
    isActive: true,
    settings: {
      defaultLanguage: 'uz',
      allowAnonymousScreening: true,
      allowAnonymousRequests: true,
      screeningFrequencyDays: 14,
      notificationsEnabled: true,
      aiAdvisorEnabled: true,
    },
  });

  // ── Users ─────────────────────────────────────────────────────────
  const users = [
    {
      uid: 'student-001',
      email: 'student@demo.school.uz',
      displayName: 'Alibek Toshmatov',
      role: 'student',
      schoolId,
      language: 'uz',
      grade: '10-A',
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
      isActive: true,
    },
    {
      uid: 'psych-001',
      email: 'psixolog@demo.school.uz',
      displayName: 'Nilufar Karimova',
      role: 'psychologist',
      schoolId,
      language: 'uz',
      specialization: 'Bolalar va o\'smirlar psixologiyasi',
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
      isActive: true,
    },
    {
      uid: 'director-001',
      email: 'direktor@demo.school.uz',
      displayName: 'Kamol Yusupov',
      role: 'director',
      schoolId,
      language: 'uz',
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
      isActive: true,
    },
    {
      uid: 'admin-001',
      email: 'admin@demo.school.uz',
      displayName: 'Admin User',
      role: 'admin',
      schoolId,
      language: 'uz',
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
      isActive: true,
    },
  ];

  for (const user of users) {
    await setDoc(doc(db, 'users', user.uid), user);
  }

  // ── Sample screening result ───────────────────────────────────────
  await addDoc(collection(db, 'screeningResults'), {
    userId: 'student-001',
    schoolId,
    isAnonymous: false,
    stage: 3,
    answers: [
      { questionId: 'q1', value: 4 },
      { questionId: 'q2', value: 3 },
      { questionId: 'q3', value: 3 },
      { questionId: 'q4', value: 4 },
      { questionId: 'q5', value: 3 },
      { questionId: 'q6', value: 3 },
      { questionId: 'q7', value: 3 },
      { questionId: 'q8', value: 4 },
      { questionId: 'q9', value: 4 },
      { questionId: 'q10', value: 2 },
      { questionId: 'q11', value: 4 },
      { questionId: 'q12', value: 4 },
      { questionId: 'q13', value: 3 },
      { questionId: 'q14', value: 3 },
      { questionId: 'q15', value: 2 },
    ],
    indicatorScores: [
      { indicator: 'mood', raw: 68, normalized: 68, label: 'good' },
      { indicator: 'stress', raw: 60, normalized: 60, label: 'good' },
      { indicator: 'social', raw: 75, normalized: 75, label: 'good' },
      { indicator: 'sleep', raw: 62, normalized: 62, label: 'good' },
      { indicator: 'relationship', raw: 71, normalized: 71, label: 'good' },
    ],
    totalScore: 67,
    riskLevel: 'low',
    completedAt: Timestamp.now(),
    language: 'uz',
  });

  // ── Sample help request ───────────────────────────────────────────
  await addDoc(collection(db, 'helpRequests'), {
    authorId: 'student-001',
    schoolId,
    isAnonymous: false,
    title: 'Imtihon davridagi qo\'rquv',
    description: 'Imtihon yaqinlashganda juda qo\'rqib ketaman, uxlay olmayapman.',
    urgency: 'medium',
    category: 'academic',
    status: 'open',
    assignedPsychologistId: null,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
    resolvedAt: null,
  });

  console.log('✅ Demo data seeded successfully!');
}
