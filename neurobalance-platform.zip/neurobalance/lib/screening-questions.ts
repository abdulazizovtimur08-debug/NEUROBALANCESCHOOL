import type { ScreeningQuestion } from '@/types';

export const SCREENING_QUESTIONS: ScreeningQuestion[] = [
  // ── STAGE 1: Mood & Stress ────────────────────────────────────────
  {
    id: 'q1',
    stage: 1,
    indicator: 'mood',
    order: 1,
    text: {
      uz: "Bugun o'zingizni qanday his qilayapsiz?",
      ru: 'Как вы себя чувствуете сегодня?',
      en: 'How are you feeling today?',
    },
  },
  {
    id: 'q2',
    stage: 1,
    indicator: 'mood',
    order: 2,
    text: {
      uz: "So'nggi hafta davomida xursand va baxtiyor his qildingizmi?",
      ru: 'Чувствовали ли вы себя счастливым и радостным на прошлой неделе?',
      en: 'Have you felt happy and joyful this past week?',
    },
  },
  {
    id: 'q3',
    stage: 1,
    indicator: 'stress',
    order: 3,
    text: {
      uz: "Hozirgi vaqtda stress yoki tashvishni his qilyapsizmi?",
      ru: 'Испытываете ли вы стресс или тревогу в настоящее время?',
      en: 'Are you experiencing stress or anxiety at the moment?',
    },
    isReverse: true,
  },
  {
    id: 'q4',
    stage: 1,
    indicator: 'stress',
    order: 4,
    text: {
      uz: "Muammolarni hal qilishda o'zingizni qodir his qilyapsizmi?",
      ru: 'Чувствуете ли вы себя способным решать проблемы?',
      en: 'Do you feel capable of handling your problems?',
    },
  },
  {
    id: 'q5',
    stage: 1,
    indicator: 'mood',
    order: 5,
    text: {
      uz: "Kelgusi kunlar haqida umidvor his qilyapsizmi?",
      ru: 'Испытываете ли вы надежду по поводу будущего?',
      en: 'Do you feel hopeful about the future?',
    },
  },

  // ── STAGE 2: Sleep & Social ───────────────────────────────────────
  {
    id: 'q6',
    stage: 2,
    indicator: 'sleep',
    order: 1,
    text: {
      uz: "Tunda yaxshi uxlayapsizmi?",
      ru: 'Хорошо ли вы спите ночью?',
      en: 'Are you sleeping well at night?',
    },
  },
  {
    id: 'q7',
    stage: 2,
    indicator: 'sleep',
    order: 2,
    text: {
      uz: "Uyg'onganingizda dam olgan va yangilangan his qilyapsizmi?",
      ru: 'Просыпаетесь ли вы отдохнувшим и обновлённым?',
      en: 'Do you wake up feeling rested and refreshed?',
    },
  },
  {
    id: 'q8',
    stage: 2,
    indicator: 'social',
    order: 3,
    text: {
      uz: "Do'stlar va oila bilan vaqt o'tkazish siz uchun qoniqarli his bermoqdami?",
      ru: 'Приносит ли вам удовлетворение время, проведённое с друзьями и семьёй?',
      en: 'Do you find time with friends and family satisfying?',
    },
  },
  {
    id: 'q9',
    stage: 2,
    indicator: 'social',
    order: 4,
    text: {
      uz: "Boshqalar bilan muloqotda o'zingizni qulay his qilyapsizmi?",
      ru: 'Чувствуете ли вы себя комфортно в общении с другими людьми?',
      en: 'Do you feel comfortable interacting with others?',
    },
  },
  {
    id: 'q10',
    stage: 2,
    indicator: 'sleep',
    order: 5,
    text: {
      uz: "Uxlashda qiyinchilik yoki erta uyg'onish muammosi bormi?",
      ru: 'Испытываете ли вы трудности с засыпанием или ранним пробуждением?',
      en: 'Do you have trouble falling asleep or waking up too early?',
    },
    isReverse: true,
  },

  // ── STAGE 3: Relationships & Overall ─────────────────────────────
  {
    id: 'q11',
    stage: 3,
    indicator: 'relationship',
    order: 1,
    text: {
      uz: "O'qituvchilar va o'quvchilar bilan munosabatingiz yaxshimi?",
      ru: 'Хорошие ли у вас отношения с учителями и одноклассниками?',
      en: 'Do you have good relationships with teachers and classmates?',
    },
  },
  {
    id: 'q12',
    stage: 3,
    indicator: 'relationship',
    order: 2,
    text: {
      uz: "Oiladagi munosabatlar sizni qo'llab-quvvatlayaptimi?",
      ru: 'Чувствуете ли вы поддержку со стороны семьи?',
      en: 'Do you feel supported by your family relationships?',
    },
  },
  {
    id: 'q13',
    stage: 3,
    indicator: 'mood',
    order: 3,
    text: {
      uz: "So'nggi ikki hafta davomida kayfiyatingiz asosan qanday bo'ldi?",
      ru: 'Каким было ваше настроение в целом за последние две недели?',
      en: 'How has your overall mood been in the past two weeks?',
    },
  },
  {
    id: 'q14',
    stage: 3,
    indicator: 'stress',
    order: 4,
    text: {
      uz: "Maktab yoki uy vazifasi stress yaratmoqdami?",
      ru: 'Вызывают ли школьные задания или домашняя работа стресс?',
      en: 'Are school assignments or homework causing you stress?',
    },
    isReverse: true,
  },
  {
    id: 'q15',
    stage: 3,
    indicator: 'social',
    order: 5,
    text: {
      uz: "Yolg'iz va tushunilmagan his qilyapsizmi?",
      ru: 'Чувствуете ли вы себя одиноким и непонятым?',
      en: 'Do you feel lonely and misunderstood?',
    },
    isReverse: true,
  },
];
