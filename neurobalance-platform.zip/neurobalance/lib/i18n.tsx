'use client';

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { AppLanguage } from '@/types';

// ──────────────────────────────────────────────────────────────────────────────
// Translation loader (client-side, JSON import)
// ──────────────────────────────────────────────────────────────────────────────

import uzTranslations from '@/locales/uz/common.json';
import ruTranslations from '@/locales/ru/common.json';
import enTranslations from '@/locales/en/common.json';

const translations: Record<AppLanguage, Record<string, unknown>> = {
  uz: uzTranslations,
  ru: ruTranslations,
  en: enTranslations,
};

// ──────────────────────────────────────────────────────────────────────────────
// Nested key resolver: "auth.signIn" → value
// ──────────────────────────────────────────────────────────────────────────────

function getNestedValue(obj: Record<string, unknown>, path: string): string {
  const keys = path.split('.');
  let current: unknown = obj;
  for (const key of keys) {
    if (typeof current !== 'object' || current === null) return path;
    current = (current as Record<string, unknown>)[key];
  }
  return typeof current === 'string' ? current : path;
}

// ──────────────────────────────────────────────────────────────────────────────
// Context
// ──────────────────────────────────────────────────────────────────────────────

interface I18nContextType {
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  t: (key: string, vars?: Record<string, string>) => string;
}

const I18nContext = createContext<I18nContextType | null>(null);

export function I18nProvider({
  children,
  defaultLanguage = 'uz',
}: {
  children: ReactNode;
  defaultLanguage?: AppLanguage;
}) {
  const [language, setLanguageState] = useState<AppLanguage>(defaultLanguage);

  const setLanguage = useCallback((lang: AppLanguage) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('nb_language', lang);
      document.documentElement.lang = lang;
    }
  }, []);

  const t = useCallback(
    (key: string, vars?: Record<string, string>): string => {
      const dict = translations[language] as Record<string, unknown>;
      let value = getNestedValue(dict, key);

      if (vars) {
        Object.entries(vars).forEach(([k, v]) => {
          value = value.replace(`{{${k}}}`, v);
        });
      }

      return value;
    },
    [language],
  );

  return (
    <I18nContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n(): I18nContextType {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}

// Convenience alias
export const useTranslation = useI18n;
