import type {
  ScreeningAnswer,
  ScreeningIndicatorScore,
  ScreeningQuestion,
  RiskLevel,
} from '@/types';
import { SCREENING_QUESTIONS } from './screening-questions';

// ──────────────────────────────────────────────────────────────────────────────
// Score normalization: Likert 1–5 → 0–100
// Reverse scored questions are flipped: (6 - value)
// ──────────────────────────────────────────────────────────────────────────────

function normalizeValue(value: number, isReverse: boolean): number {
  const adjusted = isReverse ? 6 - value : value;
  return ((adjusted - 1) / 4) * 100;
}

function getLabel(
  score: number,
): 'excellent' | 'good' | 'moderate' | 'poor' | 'critical' {
  if (score >= 80) return 'excellent';
  if (score >= 60) return 'good';
  if (score >= 40) return 'moderate';
  if (score >= 20) return 'poor';
  return 'critical';
}

function getRiskLevel(totalScore: number): RiskLevel {
  if (totalScore >= 75) return 'none';
  if (totalScore >= 55) return 'low';
  if (totalScore >= 40) return 'moderate';
  if (totalScore >= 25) return 'high';
  return 'critical';
}

// ──────────────────────────────────────────────────────────────────────────────
// Main scoring function
// ──────────────────────────────────────────────────────────────────────────────

export function calculateScreeningScores(
  answers: ScreeningAnswer[],
): {
  indicatorScores: ScreeningIndicatorScore[];
  totalScore: number;
  riskLevel: RiskLevel;
} {
  const questionMap = new Map<string, ScreeningQuestion>(
    SCREENING_QUESTIONS.map((q) => [q.id, q]),
  );

  // Group answers by indicator
  const grouped: Record<string, number[]> = {};

  for (const answer of answers) {
    const q = questionMap.get(answer.questionId);
    if (!q) continue;

    const normalized = normalizeValue(answer.value, q.isReverse ?? false);
    if (!grouped[q.indicator]) grouped[q.indicator] = [];
    grouped[q.indicator].push(normalized);
  }

  const indicators = ['mood', 'stress', 'social', 'sleep', 'relationship'];
  const indicatorScores: ScreeningIndicatorScore[] = indicators.map(
    (indicator) => {
      const values = grouped[indicator] ?? [];
      const raw = values.length
        ? values.reduce((a, b) => a + b, 0) / values.length
        : 50; // default mid-point if no questions answered

      return {
        indicator,
        raw: Math.round(raw * 10) / 10,
        normalized: Math.round(raw),
        label: getLabel(raw),
      };
    },
  );

  const totalScore =
    Math.round(
      indicatorScores.reduce((sum, s) => sum + s.normalized, 0) /
        indicatorScores.length,
    );

  return {
    indicatorScores,
    totalScore,
    riskLevel: getRiskLevel(totalScore),
  };
}

// ──────────────────────────────────────────────────────────────────────────────
// Helper: get color class for score
// ──────────────────────────────────────────────────────────────────────────────

export function getScoreColor(score: number): string {
  if (score >= 80) return 'text-calm-600';
  if (score >= 60) return 'text-calm-500';
  if (score >= 40) return 'text-warm-500';
  if (score >= 20) return 'text-orange-500';
  return 'text-red-600';
}

export function getScoreBg(score: number): string {
  if (score >= 80) return 'bg-calm-100 text-calm-700';
  if (score >= 60) return 'bg-calm-50 text-calm-600';
  if (score >= 40) return 'bg-warm-100 text-warm-700';
  if (score >= 20) return 'bg-orange-100 text-orange-700';
  return 'bg-red-100 text-red-700';
}

export function getRiskColor(risk: RiskLevel): string {
  const map: Record<RiskLevel, string> = {
    none: 'text-calm-600',
    low: 'text-calm-500',
    moderate: 'text-warm-500',
    high: 'text-orange-600',
    critical: 'text-red-600',
  };
  return map[risk];
}

export function getRiskBadgeVariant(
  risk: RiskLevel,
): 'default' | 'secondary' | 'destructive' | 'outline' {
  if (risk === 'critical' || risk === 'high') return 'destructive';
  if (risk === 'moderate') return 'secondary';
  return 'default';
}
